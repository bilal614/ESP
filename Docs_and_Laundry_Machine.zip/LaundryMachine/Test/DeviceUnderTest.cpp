// wrapping the .ino files

#include "ArduinoWrapper.h"

#include "CoinWallet.ino"
#include "ProgramExecutor.ino"
#include "ProgramSelect.ino"
#include "ProgramSettings.ino"
