#ifndef IBUZZER_H
#define IBUZZER_H

class IBuzzer
{
public:
  //input
  virtual void SetBuzzer(int ms) = 0;
};

#endif


